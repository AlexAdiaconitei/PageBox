// Meridian 01 base — all dimensions in mm.
wall = 2.4;
board_x = 100;
board_y = 80;
standoff = 6;

module base() {
  difference() {
    cube([board_x + wall * 2, board_y + wall * 2, 26]);
    translate([wall, wall, wall]) cube([board_x, board_y, 30]);
  }
}

base();
