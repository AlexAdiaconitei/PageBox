// Press fit, 0.2 mm clearance. Vent slots over the OCXO can.
include <base.scad>

lid_h = 4;
vent = 1.6;
