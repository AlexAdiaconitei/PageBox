Meridian 01 — enclosure files
=============================

base.scad     parametric, edit `wall` and re-render
lid.scad      press fit, 0.2 mm clearance
gasket.dxf    2 mm neoprene, cut or punch

Printed in PETG at 0.2 mm. PLA creeps at the temperature the OCXO
holds and the lid stops fitting after about a month.
